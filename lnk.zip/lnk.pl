#! c:\perl\bin\perl.exe
#-----------------------------------------------------------
# This is a simple script to demonstrate the use of the LNK.pm module.
#
# History:
#   20180319 - updated to include displaying icon filename path
#
# copyright 2011-2018 Quantum Research Analytics, LLC
# Author: H. Carvey, keydet89@yahoo.com
#-----------------------------------------------------------
use strict;
use LNK;

my @files;
my $file = shift || die "You must enter a file name or dir path\.\n";

my %vals = (0 => "guid",
						1 => "mtime",
            2 => "atime",
            3 => "ctime",
            4 => "workingdir",
            5 => "basepath",
            6 => "description",
            7 => "devicename",
            8 => "netname",
            9 => "shitemidlist",
            10 => "vol_sn",
            11 => "vol_type",
            12 => "commandline",
            13 => "iconfilename",
            14 => "hotkey",
            15 => "showcmd");

if (-d $file) {
	$file = $file."\\" unless ($file =~ m/\\$/);
	opendir(DIR,$file) || die "Could not open directory ".$file.": $!\n";
	my @d = readdir(DIR);
	closedir(DIR);
	
	foreach (@d) {
		next if ($_ =~ m/^\./);
#		next unless ($_ =~ m/\.lnk$/);
		push(@files,$file.$_);
	}

}
elsif (-f $file) {
	push(@files,$file);
}
else {}

foreach my $f (@files) {
	my $lnk = LNK->new();
	print "File: ".$f."\n";
	my %shrt = $lnk->getLNK($f);
	
	foreach my $i (0..(scalar(keys %vals) - 1)) {
		if (exists $shrt{$vals{$i}}) {
			if ($vals{$i} =~ m/time$/) {
				printf "%-17s  ".gmtime($shrt{$vals{$i}})." Z\n",$vals{$i};
			}
			elsif ($vals{$i} eq "hotkey" || $vals{$i} eq "showcmd") {
				printf "%-18s 0x%-30x\n",$vals{$i},$shrt{$vals{$i}};
			}
			elsif ($vals{$i} eq "shitemidlist") {
				printf "%-17s  %-30s\n",$vals{$i},$shrt{$vals{$i}};
				print "**Shell Items Details (times in UTC)**\n";
				my %si = $lnk->getShellItems();
				foreach my $i (1..((scalar keys %si) - 1)) {
					
					my $mft_ref = "";
					if (exists $si{$i}{mft_rec_num} && $si{$i}{mft_seq_num}) {
						$mft_ref = "[".$si{$i}{mft_rec_num}."/".$si{$i}{mft_seq_num}."]";
					}
				
					printf "  C:%-18s  M:%-18s  A:%-18s ".$si{$i}{name}."  (".$si{$i}{version}.")  ".$mft_ref."\n",$si{$i}{ctime}, $si{$i}{mtime}, $si{$i}{atime};		
				}
			}
			else {
				printf "%-17s  %-30s\n",$vals{$i},$shrt{$vals{$i}};
			}
		}
	}
	print "\n";

# Process LinkFlags
# I.e., fun with flags
# Also, look for "toolmarks" by also checking unused bits, per spec
my %flags = (0x01 => "HasLinkTargetIDList",
             0x02 => "HasLinkInfo",
             0x04 => "HasName",
             0x08 => "HasRelativePath",
             0x10 => "HasWorkingDir",
             0x20 => "HasArguments",
             0x40 => "HasIconLocation",
						 0x80 => "IsUnicode",
             0x100 => "ForceNoLinkInfo",
             0x200 => "HasExpString",
             0x400 => "RunInSeparateProcess",
             0x800 => "UnUsed1",
             0x1000 => "HasDarwin",
             0x2000 => "RunAsUser",
             0x4000 => "HasExpIcon",
             0x8000 => "NoPidlAlias",
             0x10000 => "UnUsed2",
             0x20000 => "RunWithShimLayer",
             0x40000 => "ForceNoLinkTrack",
             0x80000 => "EnableTargetMetadata",
             0x00100000 => "DisableLinkPathTracking",
             0x00200000 => "DisableKnownFolderTracking",
             0x00400000 => "DisableKnownFolderAlias",
             0x00800000 => "AllowLinkToLink",
             0x01000000 => "UnaliasOnSave",
             0x02000000 => "PreferEnvironmentPath",
             0x04000000 => "KeepLocalIDListForUNCTarget",
             0x08000000 => "Bit27",
             0x10000000 => "Bit28",
             0x20000000 => "Bit29",
             0x40000000 => "Bit30",
             0x80000000 => "Bit31");
             
my @lnkflags = ();

foreach my $k (sort keys %flags) {
	push(@lnkflags,$flags{$k}) if ($shrt{linkflags} & $k);
}

if (scalar @lnkflags > 0) {
	print "***LinkFlags***\n";
	print join('|',@lnkflags)."\n";
	print "\n";
}

# Process any Extra Data Blocks	
	my %edb = $lnk->getEDB();
		
	if (exists($edb{"PropertyStoreDataBlock"})) {
		print "***PropertyStoreDataBlock***\n";
		print "GUID/ID pairs:\n";
		my %psdb = $lnk->getPropertyStoreDataBlock($edb{"PropertyStoreDataBlock"});
		foreach my $i (sort keys %psdb) {
			if (exists $psdb{$i}{data}) {
				printf "%-42s    $psdb{$i}{descr}: $psdb{$i}{data}\n",$i;
			}
			else {
				printf "%-42s\n",$i;
			}
		}
	}
	
	if (exists($edb{"EnvironmentVariableDataBlock"})) {
		print "\n";
		print "***EnvironmentVariableDataBlock***\n";
		print "EnvironmentVariableDataBlock: ".$lnk->getEnvironmentVariableDataBlock($edb{"EnvironmentVariableDataBlock"})."\n";
		
	}
	
	if (exists($edb{"KnownFolderDataBlock"})) {
		print "\n";
		print "***KnownFolderDataBlock***\n";
		$lnk->getKnownFolderDataBlock($edb{"KnownFolderDataBlock"});
	}
	
	if (exists($edb{"ConsoleFEDataBlock"})) {
		print "\n";
		print "***ConsoleFEDataBlock***\n";
		print "Code page: ".$lnk->getConsoleFEDataBlock($edb{"ConsoleFEDataBlock"})."\n";
	}
	
	if (exists($edb{"TrackerDataBlock"})) {
		print "\n";
		print "***TrackerDataBlock***\n";
		$lnk->getTrackerDataBlock($edb{"TrackerDataBlock"});
#		print "\n";
#		$lnk->probe($edb{"TrackerDataBlock"});
	} 
}


